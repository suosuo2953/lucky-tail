import { combineReducers } from 'redux';
import createReducer from 'reducers/createReducer';

const reducer = combineReducers({
  categoryViewer: createReducer('FETCH_CATEGORISE'),
  mockapiViewer: createReducer('FETCH_MOCKAPIS'),
});

export default reducer;
