import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  Layout,
  Row,
  Col,
  Dropdown,
  Select,
  Input,
  Button,
  Tag,
  Icon,
  Menu,
  Modal,
  message,
} from 'antd';
import * as mockApiActions from 'actions/mockapi';
import * as categoryActions from 'actions/category';

const colors = {
  GET: 'pink',
  HEAD: 'red',
  POST: 'green',
  PUT: 'cyan',
  DELETE: 'orange',
  CONNECT: 'blue',
  OPTIONS: 'purple',
  TRACE: '#108ee9',
  PATCH: '#f50',
};

const actionCreators = Object.assign(mockApiActions, categoryActions);

@connect(
  state => ({
    categoryViewer: state.categoryViewer,
    mockapiViewer: state.mockapiViewer,
  }),
  dispatch => bindActionCreators(actionCreators, dispatch),
)
export default class Home extends Component {

  static propTypes = {
    history: PropTypes.object,
    categoryViewer: PropTypes.object,
    mockapiViewer: PropTypes.object,
    fetchCategorise: PropTypes.func,
    fetchMockapis: PropTypes.func,
  };

  componentWillMount() {
    this.props.fetchCategorise();
    this.props.fetchMockapis();
  }

  onNewMockapiClick = () => {
    this.props.history.push('/add');
  }

  onMenuClick = id => ({ key }) => {
    switch (key) {
      case 'edit':
        this.props.history.push(`/edit/${id}`);
        break;
      case 'delete':
        this.deleteMockapi(id);
        break;
      default:
        break;
    }
  }

  onViewClick = id => e => (this.props.history.push(`/view/${id}`));

  onCategoryChange = () => {

  }

  onSearch = keywords =>
    (this.props.fetchMockapis({ keywords }, resovled => (this.setState({ keywords }))))

  deleteMockapi = (id) => {
    const { props } = this;
    Modal.confirm({
      title: 'Warning',
      content: 'Are you sure to delete it?',
      okText: 'Ok',
      cancelText: 'Cancel',
      onOk: () => {
        props.deleteMockapi(
          id,
          (resovled, dispatch) => {
            message.success(resovled.data.message);
            dispatch(props.fetchMockapis());
          },
          rejected => message.success(rejected.data.message));
      },
      onCancel: () => {},
    });
  }

  menu = id => (
    <Menu onClick={this.onMenuClick(id)}>
      <Menu.Item key="edit">
        <Icon type="edit" />
        &nbsp;Edit
      </Menu.Item>
      <Menu.Item key="delete">
        <Icon type="delete" />
        &nbsp;Delete
      </Menu.Item>
    </Menu>
  )

  render() {
    const { mockapiViewer, categoryViewer } = this.props;
    return (
      <Layout>
        <Layout.Header>
          <Row style={{ width: '980px', margin: '0 auto' }}>
            <Col span={1}>
              <h1 style={{ color: '#fff' }}>
                <Icon type="api" />
              </h1>
            </Col>
            <Col span={21}>
              <Input.Search
                style={{ width: 240, marginRight: '20px' }}
                placeholder="Search Mock API"
                onSearch={this.onSearch}
              />
              <Select
                placeholder="Please select category."
                style={{ width: 120, marginRight: '20px' }}
                onChange={this.onCategoryChange}
              >
                {categoryViewer.success && categoryViewer.categories.map(category => (
                  <Select.Option
                    key={category.id}
                    value={category.id}
                  >
                    {category.name}
                  </Select.Option>
                ))}
              </Select>
            </Col>
            <Col span={2} style={{ textAlign: 'right' }}>
              <Button type="primary" onClick={this.onNewMockapiClick}>NEW</Button>
            </Col>
          </Row>
        </Layout.Header>
        <Layout.Content style={{ width: '980px', margin: '0 auto' }}>
          {mockapiViewer.success && mockapiViewer.mockapis.map(mockapi => (
            <Row key={mockapi.id}style={{ marginTop: '16px' }}>
              <Col span={18}>
                <h3
                  onClick={this.onViewClick(mockapi.id)}
                  style={{ fontSize: '26px', marginBottom: '8px', cursor: 'pointer' }}
                >
                  {mockapi.uri}
                </h3>
                <Tag color={colors[mockapi.method]} style={{ cursor: 'auto' }}>
                  {mockapi.method}
                </Tag>
                <Tag color="#2db7f5" style={{ cursor: 'auto' }}>
                  {mockapi.category.name}
                  <Icon type="tag-o" style={{ marginLeft: 4 }} />
                </Tag>
              </Col>
              <Col span={6} style={{ textAlign: 'right' }}>
                <Dropdown
                  overlay={this.menu(mockapi.id)}
                  trigger={['hover']}
                  style={{ marginBottom: '26px' }}
                >
                  <Icon type="ellipsis" style={{ fontSize: '22px' }} />
                </Dropdown>
                <p style={{ fontSize: '14px' }}>
                  <Icon type="cloud-download" style={{ color: '#f50' }} />
                  &nbsp;
                  <span>{mockapi.hit}</span>
                </p>
              </Col>
            </Row>
          ))}
        </Layout.Content>
        <Layout.Footer style={{ textAlign: 'center' }}>
          Copyrights ©2017  Tuniu inc.
        </Layout.Footer>
      </Layout>
    );
  }
}
