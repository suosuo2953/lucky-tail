import React from 'react';
import { Switch, Route } from 'react-router';
import Home from './Home';
import Editor from './Editor';

export default () => (
  <Switch>
    <Route exact path="/" component={Home} />
    <Route path="/add" component={Editor} />
    <Route path="/edit/:id" component={Editor} />
    <Route path="/view/:id" component={Editor} />
  </Switch>
);
