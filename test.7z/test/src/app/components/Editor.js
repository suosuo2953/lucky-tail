import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  Layout,
  Row,
  Col,
  Breadcrumb,
  Input,
  Button,
  message,
  Select,
  Icon,
} from 'antd';
import upperCaseFirst from 'upper-case-first';
import AceEditor from 'react-ace';
import 'brace/mode/json';
import 'brace/theme/textmate';
import * as mockApiActions from 'actions/mockapi';
import * as categoryActions from 'actions/category';

const methods = ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'CONNECT', 'OPTIONS', 'TRACE', 'PATCH'];

const actionCreators = Object.assign(mockApiActions, categoryActions);

@connect(
  state => ({
    categoryViewer: state.categoryViewer,
  }),
  dispatch => bindActionCreators(actionCreators, dispatch),
)
export default class Editor extends Component {

  static propTypes = {
    categoryViewer: PropTypes.object,
    fetchCategorise: PropTypes.func,
    fetchMockapi: PropTypes.func,
    match: PropTypes.object,
  };

  state = {
    content: '',
    category: '',
    uri: '',
    method: 'GET',
    mode: 'add',
  }

  componentWillMount() {
    if (!this.props.categoryViewer.success) {
      this.props.fetchCategorise();
    }
    const { match } = this.props;
    if (match && (match.path.indexOf('view') > 0 || match.path.indexOf('edit') > 0)) {
      this.props.fetchMockapi(
        match.params.id,
        (resolved) => {
          this.setState(resolved.data.mockapi);
        },
        // (rejected) => {

        // }
      );
    }
    if (match && match.path.indexOf('view') > 0) {
      this.setState({ mode: 'view' });
    }
    if (match && match.path.indexOf('add') > 0) {
      this.setState({ mode: 'add' });
    }
    if (match && match.path.indexOf('edit') > 0) {
      this.setState({ mode: 'edit' });
    }
  }

  onFormatClick = () => {
    if (!this.state.content) {
      return;
    }
    let { content } = this.state;
    content = JSON.parse(content);
    content = JSON.stringify(content, null, 2);
    this.setState({ content });
  }

  onCompactClick = () => {
    if (!this.state.content) {
      return;
    }
    let { content } = this.state;
    content = JSON.parse(content);
    content = JSON.stringify(content).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
    this.setState({ content });
  }

  onEditorChange = content => (this.setState({ content }))

  onCategoryChange = category => (this.setState({ category }))

  onMethodChange = method => (this.setState({ method }))

  onUriChange = e => (this.setState({ uri: e.target.value }))

  onSaveClick = () => {
    const { state, props } = this;
    const { categoryViewer } = this.props;
    const params = {
      category: state.category || categoryViewer.categories[0].id,
      uri: state.uri,
      content: state.content,
      method: state.method,
    };
    const success = (resolved) => {
      message.success(resolved.data.message);
      if (resolved.data.success) {
        props.history.replace('/');
      }
    };
    const error = rejected => (message.success(rejected.data.message));
    if (state.mode === 'add') {
      props.createMockapi(params, success, error);
      return;
    }
    if (state.mode === 'edit') {
      props.updateMockapi(props.match.params.id, params, success, error);
    }
  }

  render() {
    const { categoryViewer } = this.props;
    const { state } = this;
    let categoryId = '';
    if (state.mode === 'view' || state.mode === 'edit') {
      categoryId = state.category;
    }
    if (state.mode === 'add' && categoryViewer.categories[0]) {
      categoryId = state.category || categoryViewer.categories[0].id;
    }
    return (
      <Layout>
        <Layout.Header>
          <Row style={{ width: '980px', margin: "0 auto" }}>
            <Col span={4}>
              <h1 style={{ color: '#fff' }}>
                <Icon type="api" />
              </h1>
            </Col>
            <Col span={20} style={{ textAlign: 'right' }}>
              <Select
                style={{ width: 160, marginRight: '20px' }}
                disabled={state.mode === 'view'}
                value={categoryId}
                onChange={this.onCategoryChange}
              >
                {categoryViewer.success && categoryViewer.categories.map(category => (
                  <Select.Option
                    key={category.id}
                    value={category.id}
                  >
                    {category.name}
                  </Select.Option>
                ))}
              </Select>
              <Input.Group compact style={{ width: 340, display: 'inline-block', marginRight: '20px' }}>
                <Select value={state.method} style={{ width: 100 }} onChange={this.onMethodChange}>
                  {methods.map(method =>
                    (<Select.Option key={method} value={method}>{method}</Select.Option>))
                  }
                </Select>
                <Input
                  style={{ width: 240, display: 'inline-block' }}
                  placeholder="Please enter API path."
                  value={state.uri}
                  disabled={state.mode === 'view'}
                  onChange={this.onUriChange}
                />
              </Input.Group>
              <Button
                type="primary"
                disabled={state.mode === 'view'}
                onClick={this.onSaveClick}
              >
                SAVE
              </Button>
            </Col>
          </Row>
        </Layout.Header>
        <Layout.Content style={{ width: '980px', margin: '0 auto' }}>
          <Breadcrumb style={{ margin: '12px 0', padding: '0 50px' }}>
            <Breadcrumb.Item><a href="/">Mock APIs</a></Breadcrumb.Item>
            <Breadcrumb.Item>{upperCaseFirst(state.mode)}</Breadcrumb.Item>
          </Breadcrumb>
          <AceEditor
            theme="textmate"
            mode="json"
            fontSize={14}
            value={state.content}
            onChange={this.onEditorChange}
            height={`${window.innerHeight - 172}px`}
            width="100%"
          />
        </Layout.Content>
        <Layout.Footer style={{ textAlign: 'center' }}>
          Copyrights ©2017  Tuniu inc.
        </Layout.Footer>
      </Layout>
    );
  }

}
