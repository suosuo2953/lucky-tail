import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import {
  BrowserRouter,
  Switch,
  Route,
} from 'react-router-dom';
import injectTapEventPlugin from 'react-tap-event-plugin';
import configureStore from 'store/configureStore';
import { App } from 'components';
import 'antd/dist/antd.less';

injectTapEventPlugin();

ReactDOM.render(
  <Provider store={configureStore()}>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </Provider>,
  document.getElementById('container'));
