export const createCategory = params => ({
  type: 'CREATE_CATEGORY',
  url: '/api/categories',
  method: 'post',
  params,
});

export const deleteCategory = id => ({
  type: 'DELETE_CATEGORY',
  url: `/api/categories/${id}`,
  method: 'delete',
});

export const updateCategory = (id, params) => ({
  type: 'UPDATE_CATEGORY',
  url: `/api/categories/${id}`,
  method: 'get',
  params,
});

export const fetchCategory = id => ({
  type: 'FETCH_CATEGORY',
  url: `/api/categories/${id}`,
  method: 'get',
});

export const fetchCategorise = params => ({
  type: 'FETCH_CATEGORISE',
  url: '/api/categories',
  method: 'get',
  params,
});
