export const createMockapi = (params, success, error) => ({
  type: 'CREATE_MOCKAPI',
  url: '/api/mockapis',
  method: 'post',
  data: params,
  success,
  error,
});

export const deleteMockapi = (id, success, error) => ({
  type: 'DELETE_MOCKAPI',
  url: `/api/mockapis/${id}`,
  method: 'delete',
  success,
  error,
});

export const updateMockapi = (id, params, success, error) => ({
  type: 'UPDATE_MOCKAPI',
  url: `/api/mockapis/${id}`,
  method: 'put',
  data: params,
  success,
  error,
});

export const fetchMockapi = (id, success, error) => ({
  type: 'FETCH_MOCKAPI',
  url: `/api/mockapis/${id}`,
  method: 'get',
  success,
  error,
});

export const fetchMockapis = (params, success, error) => ({
  type: 'FETCH_MOCKAPIS',
  url: '/api/mockapis',
  method: 'get',
  params,
  success,
  error,
});
