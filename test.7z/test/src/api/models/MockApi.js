import mongoose from 'mongoose';

const MockapiSchema = new mongoose.Schema({
  uri: {
    type: String,
    required: true,
  },
  method: {
    type: String,
    required: true,
  },
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: true,
  },
  description: {
    type: String,
  },
  content: {
    type: String,
    required: true,
  },
  hit: {
    type: Number,
    default: 0,
  },
}, {
  versionKey: false,
});

MockapiSchema.index({ uri: 1, method: 1 }, { unique: true });
MockapiSchema.index({ uri: 'text', description: 'text', content: 'text' });

export default mongoose.model('Mockapi', MockapiSchema);
