const env = process.env.NODE_ENV || 'development';

export const NODE_ENV = env;
export const __DEV__ = (env === 'development'); // eslint-disable-line
export const __PROD__ = (env === 'production'); // eslint-disable-line
export const HOST = '172.17.35.205';
export const PORT = __PROD__ ? 80 : 3000;
export { default as database } from './database';
