import renameKeys from 'deep-rename-keys';
import { lowerCase } from 'lodash';
import pluralize from 'pluralize';

const processResult = result =>
  renameKeys(JSON.parse(JSON.stringify(result)), key => (key === '_id' ? 'id' : key));

const processParams = params =>
  renameKeys(params, key => (key === 'id' ? '_id' : key));

const addOne = (Collection, params) => (
  new Promise((resolve) => {
    const instance = new Collection(params);
    instance.save()
      .then((result) => {
        resolve({
          success: true,
          message: `${Collection.modelName} has been added.`,
          [lowerCase(Collection.modelName)]: processResult(result),
        });
      })
      .catch((error) => {
        resolve({
          success: false,
          message: error.message,
          errors: error.errors,
        });
      });
  })
);

const deleteOne = (Collection, params) => (
  new Promise((resolve) => {
    Collection.findByIdAndRemove(processParams(params))
      .then(() => {
        resolve({
          success: true,
          message: `${Collection.modelName} has been deleted.`,
        });
      })
      .catch((error) => {
        resolve({
          success: false,
          message: error.message,
          errors: error.errors,
        });
      });
  })
);

const updateOne = (Collection, parameters, args) => {
  const params = processParams(parameters);
  return new Promise((resolve) => {
    Collection.update(Object.assign(params, args))
      .then(({ ok }) => {
        if (ok) {
          Collection.findById(params)
            .then((result) => {
              resolve({
                success: true,
                message: `${Collection.modelName} has been updated.`,
                [lowerCase(Collection.modelName)]: processResult(result),
              });
            })
            .catch((error) => {
              resolve({
                success: false,
                message: error.message,
                errors: error.errors,
              });
            });
          return;
        }
        resolve(null);
      })
      .catch((error) => {
        resolve({
          success: false,
          message: error.message,
          errors: error.errors,
        });
      });
  });
};

const getOne = (Collection, params) => (
  new Promise((resolve) => {
    Collection.findById(params.id)
      .then((result) => {
        resolve({
          success: true,
          [lowerCase(Collection.modelName)]: processResult(result),
        });
      })
      .catch((error) => {
        resolve({
          success: false,
          message: error.message,
          errors: error.errors,
        });
      });
  })
);

const getAll = (Collection, promise) => (
  new Promise((resolve) => {
    promise
      .then((result) => {
        resolve({
          success: true,
          [pluralize(lowerCase(Collection.modelName))]: processResult(result),
        });
      })
      .catch((error) => {
        resolve({
          success: false,
          message: error.message,
          errors: error.errors,
        });
      });
  })
);

const getAllWithPagination = () => {

};

module.exports = (param) => {
  const app = param;
  if (app.context.mongoose) {
    return;
  }
  app.context.mongoose = {
    addOne,
    deleteOne,
    updateOne,
    getOne,
    getAll,
    getAllWithPagination,
    processParams,
  };
};
