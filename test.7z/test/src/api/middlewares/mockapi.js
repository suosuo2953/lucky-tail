import { isEmpty } from 'lodash';
import Mockapi from '../models/Mockapi';

export default () => async (ctx, next) => {
  let mockapi = {};
  try {
    mockapi = await Mockapi.findOneAndUpdate({
      uri: ctx.path,
      method: ctx.method.toUpperCase(),
    }, { $inc: { hit: 1 } });
  } catch (e) {
    console.log(e);
  }
  if (!isEmpty(mockapi)) {
    ctx.body = mockapi.content;
    ctx.set('Content-Type', 'application/json');
  }
  await next();
};
