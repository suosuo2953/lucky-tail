import Category from '../models/Category';

const addOne = async (ctx, next) => {
  ctx.body = await ctx.mongoose.addOne(Category, ctx.request.body);
  await next();
};

const deleteOne = async (ctx, next) => {
  ctx.body = await ctx.mongoose.deleteOne(Category, ctx.params);
  await next();
};

const updateOne = async (ctx, next) => {
  ctx.body = await ctx.mongoose.updateOne(Category, ctx.params,
    Object.assign(ctx.params, ctx.request.body));
  await next();
};


const findOne = async (ctx, next) => {
  ctx.body = await ctx.mongoose.getOne(Category, ctx.params);
  await next();
};

const findAll = async (ctx, next) => {
  ctx.body = await ctx.mongoose.getAll(Category, Category.find({}));
  await next();
};

export default {
  addOne,
  deleteOne,
  updateOne,
  findOne,
  findAll,
};
