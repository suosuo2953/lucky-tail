import Mockapi from '../models/Mockapi';

const addOne = async (ctx, next) => {
  ctx.body = await ctx.mongoose.addOne(Mockapi, ctx.request.body);
  await next();
};

const deleteOne = async (ctx, next) => {
  ctx.body = await ctx.mongoose.deleteOne(Mockapi, ctx.params);
  await next();
};

const updateOne = async (ctx, next) => {
  ctx.body = await ctx.mongoose.updateOne(Mockapi, ctx.params,
    Object.assign(ctx.params, ctx.request.body));
  await next();
};

const findOne = async (ctx, next) => {
  ctx.body = await ctx.mongoose.getOne(Mockapi, ctx.params);
  await next();
};

const findAll = async (ctx, next) => {
  const { pageIndex = 1, pageSize = 20, keywords } = ctx.query;
  let search = {};
  if (keywords) {
    search = { $text: { $search: keywords } };
  }
  const promise = Mockapi.find(search)
    .populate('category')
    .limit(Number(pageSize))
    .skip(Number(pageSize) * Number(pageIndex - 1))
    .exec();
  ctx.body = await ctx.mongoose.getAll(Mockapi, promise);
  await next();
};

export default {
  addOne,
  deleteOne,
  updateOne,
  findOne,
  findAll,
};
