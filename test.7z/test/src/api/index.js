import Koa from 'koa';
import logger from 'koa-logger';
import bodyParser from 'koa-bodyparser';
import serve from 'koa-static';
import send from 'koa-send';
import Router from 'koa-router';
import mongoose from './middlewares/mongoose';
import mockapi from './middlewares/mockapi';
import router from './routes';
import {
  HOST,
  PORT,
  __DEV__,
  __PROD__,
  database,
} from './config';

const databaseUri = __DEV__ ? database.development : database.production;

const api = new Koa();
api.use(logger());
api.use(bodyParser());
api.use(router.routes());
api.use(mockapi());
if (__PROD__) {
  api.use(serve(`${__dirname}/public`));
  const indexRouter = new Router();
  indexRouter.get(/^\/^(api)(?:\/|$)/, async (ctx, next) => {
    await send(ctx, `${__dirname}/public/index.html`);
    await next();
  });
}
mongoose(api);

(async () => {
  try {
    const db = await database.connect(databaseUri);
    console.log(`Connected to database ${db.host}:${db.port}/${db.name}`);
  } catch (error) {
    console.error('Unable to connect to database');
  }
  await api.listen(PORT, HOST, () => {
    console.log('API Server running at http://%s:%s.', HOST, PORT);
  });
})();
