import Router from 'koa-router';
import category from './category';
import mockapi from './mockapi';

const router = new Router({ prefix: '/api' });

router.use(category.routes());
router.use(mockapi.routes());

export default router;
