import Router from 'koa-router';
import mockapi from '../controllers/mockapi';

const router = new Router();

router
  .post('/mockapis', mockapi.addOne)
  .delete('/mockapis/:id', mockapi.deleteOne)
  .put('/mockapis/:id', mockapi.updateOne)
  .get('/mockapis/:id', mockapi.findOne)
  .get('/mockapis', mockapi.findAll);

export default router;
