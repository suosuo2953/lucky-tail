import Router from 'koa-router';
import category from '../controllers/category';

const router = new Router();

router
  .post('/categories', category.addOne)
  .delete('/categories/:id', category.deleteOne)
  .put('/categories/:id', category.updateOne)
  .get('/categories/:id', category.findOne)
  .get('/categories', category.findAll);

export default router;
