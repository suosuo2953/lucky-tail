const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const WriteFilePlugin = require('write-file-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

module.exports = (env) => {
  const __DEV__ = env.development; // eslint-disable-line
  const __PROD__ = env.production; // eslint-disable-line
  const PATHS = {
    app: path.join(__dirname, './src/app'),
    dist: path.join(__dirname, __DEV__ ? './src/app/dist' : './src/api/public'),
    publicPath: './',
  };

  const webpackConfig = {
    entry: [`${PATHS.app}/index`],
    module: {},
    resolve: {
      alias: {
        actions: `${PATHS.app}/actions`,
        assets: `${PATHS.app}/assets`,
        components: `${PATHS.app}/components`,
        middlewares: `${PATHS.app}/middlewares`,
        reducers: `${PATHS.app}/reducers`,
        store: `${PATHS.app}/store`,
      },
    },
    // performance: {},
    plugins: [],
  };
  if (__DEV__) {
    webpackConfig.entry.push(
      'webpack-dev-server/client?http://localhost:7070',
      'webpack/hot/only-dev-server');
    webpackConfig.devtool = 'inline-source-map';
  }

  webpackConfig.output = {
    path: PATHS.dist,
    filename: 'app-[hash].js',
    publicPath: PATHS.publicPath,
  };

  webpackConfig.module.rules = [{
    test: /\.js$/,
    exclude: /(node_modules|bower_components)/,
    use: 'babel-loader',
  }];

  if (__DEV__) {
    webpackConfig.module.rules.push({
      test: /\.less$/,
      use: ['style-loader', 'css-loader', 'less-loader'],
    });
  }

  if (__PROD__) {
    webpackConfig.module.rules.push({
      test: /\.less$/,
      use: ExtractTextPlugin.extract({
        fallback: 'style-loader',
        use: ['css-loader', 'less-loader'],
      }),
    });
  }

  webpackConfig.plugins = [
    new HtmlWebpackPlugin({
      template: `${PATHS.app}/assets/template.html`,
      inject: 'body',
    }),
  ];
  if (__DEV__) {
    webpackConfig.plugins.push(
      new webpack.DefinePlugin({
        __DEV__: JSON.stringify(true),
      }),
      new WriteFilePlugin(),
      new webpack.HotModuleReplacementPlugin());
  }
  if (__PROD__) {
    webpackConfig.plugins.push(
      new webpack.DefinePlugin({
        __DEV__: JSON.stringify(false),
        'process.env.NODE_ENV': JSON.stringify('production'),
      }),
      new ExtractTextPlugin('app-[hash].css'),
      new webpack.optimize.OccurrenceOrderPlugin(),
      new webpack.optimize.AggressiveMergingPlugin(),
      new webpack.optimize.CommonsChunkPlugin({
        name: 'vendor',
        filename: 'framework-[hash].js',
        minChunks: module => (
          module.resource &&
          module.resource.indexOf('node_modules') !== -1 &&
          module.resource.indexOf('.css') === -1
        ),
      }),
      new webpack.optimize.UglifyJsPlugin({
        compress: {
          unused: true,
          dead_code: true,
          warnings: false,
          screw_ie8: true,
        },
        comments: false,
      }));
  }

  webpackConfig.devServer = {
    publicPath: PATHS.publicPath,
    contentBase: PATHS.dist,
    historyApiFallback: true,
    compress: true,
    inline: true,
    port: 7070,
    proxy: {
      '/api': 'http://127.0.0.1:3000',
    },
  };
  return webpackConfig;
};
